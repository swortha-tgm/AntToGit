package hello;
/**
 * 
 * @author Simon Wortha
 * @version 2015014
 *
 */
public class Hello {
	public static void main(String[] args) {
		System.out.println("Hello World");
	}
	/**
	 * Vereinfacht den Testcase
	 * 
	 * @return hello world
	 */
	public String getString() {
		return "Hello World";
	}
}
